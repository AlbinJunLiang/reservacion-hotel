import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-6TOHG4HW.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-WYPTAJAG.js";
import "./chunk-AINWYKAL.js";
import "./chunk-XLG5FYR5.js";
import "./chunk-ROMENTET.js";
import "./chunk-SGXB2MII.js";
import "./chunk-STYFELFB.js";
import "./chunk-HD7F3KTM.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-3JB6HOOL.js";
import "./chunk-IJZ4HBZU.js";
import "./chunk-V5HOVMXV.js";
import "./chunk-4J25ECOH.js";
import "./chunk-IEMOZLTW.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
