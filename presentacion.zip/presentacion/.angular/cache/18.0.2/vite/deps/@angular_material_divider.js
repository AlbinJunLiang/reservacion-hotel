import {
  MatDivider,
  MatDividerModule
} from "./chunk-AOK4PDFU.js";
import "./chunk-3JB6HOOL.js";
import "./chunk-IJZ4HBZU.js";
import "./chunk-V5HOVMXV.js";
import "./chunk-4J25ECOH.js";
import "./chunk-IEMOZLTW.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
