export const environment = {
    servidor : "http://localhost:9000"
};
