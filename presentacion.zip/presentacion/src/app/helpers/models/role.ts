export enum Role{
    Admin = 1,
    Especial = 2,
    Recepcionista = 3,
    Cliente = 4
}